package main;

public enum Products {
	
	APPLE, CHERRY, PEAR, GRAPES, ORANGE, MANGO, PINEAPPLE, PLUM, APRICOT;

}
