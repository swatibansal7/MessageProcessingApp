package main;

public enum Operation {

	ADD , SUBSTRACT, MULTIPLY;
}
